package com.tankstars.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Scaling;
import org.w3c.dom.Text;

import java.awt.*;
import java.lang.annotation.ElementType;

public class light_tank_actor extends Image {

    public Body body;
    public light_tank_actor(GameWorld world){

        Texture texture = new Texture("light_tank.png");
        this.setDrawable(new TextureRegionDrawable(new TextureRegion(texture,0,256, texture.getWidth(), texture.getHeight())));

        BodyDef tankBodyDef = new BodyDef();
        tankBodyDef.type = BodyDef.BodyType.DynamicBody;
        tankBodyDef.position.set(20, 80);

        this.body=world.box2dworld.createBody(tankBodyDef);
        BodyUserData data=new BodyUserData();
        data.type="light_tank";
        data.health=100;
        data.speed=10f;

        this.body.setUserData(data);



        // polygon shape
        PolygonShape tankShape = new PolygonShape();
        tankShape.setAsBox(10, 10);



        // fixture definition
        FixtureDef tankFixtureDef = new FixtureDef();
        tankFixtureDef.density = 3;
        tankFixtureDef.friction = 0.5f;
        tankFixtureDef.restitution = 0.1f;
        tankFixtureDef.shape = tankShape;
        body.createFixture(tankFixtureDef);



        tankShape.dispose();

        this.setPosition(body.getPosition().x-5,body.getPosition().y-5);
        this.setSize(20,20);
        this.setScaling(Scaling.stretch);
        this.setAlign(Align.center);






    }

    @Override
    public void draw(Batch batch,float parentAlpha){


    }
    @Override
    public void act(float delta){
        super.act(delta);
        setOrigin(5,5);
        setRotation(MathUtils.radiansToDegrees*body.getAngle());
        setPosition(body.getPosition().x-5,body.getPosition().y-5);
    }

}
