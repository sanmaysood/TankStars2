package com.tankstars.game;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Mesh;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelBatch;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.g3d.model.MeshPart;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.FitViewport;


public class GameScreen implements Screen {
    private Stage stage;
    private Skin skin;

    private Label gameLabel,player_1_Label,player_2_Label;
    private shootButton shootButton_P_1;
    private shootButton shootButton_P_2;
    private powerButton powerButton_P_1,powerButton_P_2;
    private TanksStars tanksStars;
    private Body box;
    private ImageButton btnOptions;
    private ImageButton btnShoot;
    private GameRenderer gameRenderer;
    private GameWorld gameWorld;
    private OrthographicCamera GUIcam;




    private float speed = 100;
    private Vector2 movement = new Vector2();
    private final float pixelsToMeters = 32;
    public GameScreen(){
        this.stage=new Stage();
    }



    @Override
    public void show() {



//        Gdx.input.setInputProcessor(new InputController(){
//            @Override
//            public boolean keyDown(int keycode){
//                switch (keycode){
//
//                    case Input.Keys.ESCAPE:
//                        ( (Game) Gdx.app.getApplicationListener()).setScreen(new OptionsScreen(tanksStars));
//                        break;
//
//                    case Input.Keys.A:
//                        movement.x = -speed;
//                        break;
//
//                    case Input.Keys.D:
//                        movement.x = speed;
//                        break;
//
//                    case Input.Keys.W:
//                        movement.y = speed;
//                        break;
//
//                    case Input.Keys.S:
//                        movement.y = -speed;
//                        break;
//
//
//                }
//                return true;
//            }
//
//            @Override
//            public boolean keyUp(int keycode) {
//                switch (keycode){
//
//                    case Input.Keys.A:
//                    case Input.Keys.D:
//                        movement.x = 0;
//                        break;
//
//
//                    case Input.Keys.W:
//                    case Input.Keys.S:
//                        movement.y = 0;
//                        break;
//
//                }
//                return true;
//            }
//        });

        FitViewport viewport = new FitViewport(800, 480);
        this.stage= new Stage(viewport);
        gameWorld= new GameWorld();
        gameRenderer= new GameRenderer(gameWorld);





        // ground definition
//        BodyDef groundBodyDef = new BodyDef();
//        groundBodyDef.type = BodyDef.BodyType.StaticBody;
//        groundBodyDef.position.set(0, 0);
//
//        // ground shape
//        ChainShape groundShape = new ChainShape();
//        groundShape.createChain(new Vector2[]{
//                new Vector2(-800, -100),
//                new Vector2(800, -100),
//        });
//
//        FixtureDef groundFixtureDef = new FixtureDef();
//        groundFixtureDef.friction = 0.5f;
//        groundFixtureDef.restitution = 0;
//        groundFixtureDef.shape = groundShape;
//
//
//        // create ground
//        world.createBody(groundBodyDef).createFixture(groundFixtureDef);
//
//        groundShape.dispose();
//
//        // create tank
//
//        BodyDef tankBodyDef = new BodyDef();
//        tankBodyDef.type = BodyDef.BodyType.DynamicBody;
//        tankBodyDef.position.set(20, 80);
//
//        // polygon shape
//        PolygonShape tankShape = new PolygonShape();
//        tankShape.setAsBox(10, 10);
//
//        // fixture definition
//        FixtureDef tankFixtureDef = new FixtureDef();
//        tankFixtureDef.density = 3;
//        tankFixtureDef.friction = 0.5f;
//        tankFixtureDef.restitution = 0.1f;
//        tankFixtureDef.shape = tankShape;
//
//        world.createBody(tankBodyDef).createFixture(tankFixtureDef);
//
//        tankShape.dispose();

        this.skin= new Skin(Gdx.files.internal("skin/craftacular-ui.json"));

        Texture backgroundTex=new Texture(Gdx.files.internal("GameBackground.png"));
        TextureRegion backgroundTexReg= new TextureRegion(backgroundTex,800,600);
        Image background=new Image(backgroundTexReg);

        gameLabel=new Label(" GameID:404",skin,"bold");
        gameLabel.setSize(250,50);
        gameLabel.setPosition(290,480);

        player_1_Label=new Label("P1",skin,"xp");
        player_1_Label.setSize(35,35);
        player_1_Label.setPosition(10,450);

        player_2_Label=new Label("P2",skin,"xp");
        player_2_Label.setSize(35,35);
        player_2_Label.setPosition(750,450);


        this.light_tank_actor=new light_tank_actor();
        this.cavalry_tank_actor=new cavalry_tank_actor();
        this.infantry_tank_actor=new infantry_tank_actor();
        this.light_tank_actor.sprite.setPosition(800-10-light_tank_actor.sprite.getWidth(),120);
        this.infantry_tank_actor.flipper();
        this.infantry_tank_actor.sprite.setPosition(10,150);
        //this.cavalry_tank_actor.sprite.setPosition(400,150);

        this.btnOptions=new ImageButton(skin);
        this.btnOptions.setSize(60,60);
        this.btnOptions.getStyle().imageUp=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("OptionsButton.png"))));
        this.btnOptions.getStyle().imageDown=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("OptionsButton.png"))));
        this.btnOptions.setPosition(800-80,600-80);

        this.btnOptions=new ImageButton(skin);
        this.btnOptions.setSize(60,60);
        this.btnOptions.getStyle().imageUp=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("OptionsButton.png"))));
        this.btnOptions.getStyle().imageDown=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("OptionsButton.png"))));
        this.btnOptions.setPosition(800-80,600-80);

        this.btnOptions=new ImageButton(skin);
        this.btnOptions.setSize(60,60);
        this.btnOptions.getStyle().imageUp=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("OptionsButton.png"))));
        this.btnOptions.getStyle().imageDown=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("OptionsButton.png"))));
        this.btnOptions.setPosition(800-80,600-80);

        this.shootButton_P_1=new shootButton();
        this.shootButton_P_2=new shootButton();
        this.shootButton_P_1.sprite.setPosition(10,70);
        this.shootButton_P_2.sprite.setPosition(750,70);

        this.powerButton_P_1=new powerButton();
        this.powerButton_P_2=new powerButton();
        this.powerButton_P_1.sprite.setPosition(10,10);
        this.powerButton_P_2.sprite.setPosition(750,10);



        stage.addActor(background);
        stage.addActor(gameLabel);
        stage.addActor(player_1_Label);
        stage.addActor(player_2_Label);
        stage.addActor(this.btnOptions);
        stage.addActor(light_tank_actor);
        stage.addActor(infantry_tank_actor);
        stage.addActor(shootButton_P_1);
        stage.addActor(shootButton_P_2);
        stage.addActor(powerButton_P_1);
        stage.addActor(powerButton_P_2);



    }

    @Override
    public void render(float delta) {
        GUIcam=(OrthographicCamera)stage.getCamera();
        GUIcam.position.set(400,300,0);


        Gdx.gl.glClearColor(0,0,0,0);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        GUIcam.update();
        gameWorld.update(delta);

        stage.act(delta);
        gameRenderer.render();
        stage.draw();


//        debugRenderer.render(world, camera.combined);

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {
        dispose();
    }

    @Override
    public void dispose() {
//        world.dispose();
//        debugRenderer.dispose();
    }
}

