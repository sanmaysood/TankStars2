package com.tankstars.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.ScreenUtils;

public class PreloginScreen implements Screen {
    private final TanksStars tanksStars;
    private Stage stage;
    private Skin skin;
    private TextButton btnPlay;
    private TextButton btnAbout;
    private TextButton btnResume;



    public PreloginScreen(TanksStars tanksStars){
        this.tanksStars=tanksStars;
        this.stage=new Stage();


    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
        stage.clear();
        this.skin= new Skin(Gdx.files.internal("skin/craftacular-ui.json"));

        Texture backgroundTex=new Texture(Gdx.files.internal("background.png"));
        TextureRegion backgroundTexReg= new TextureRegion(backgroundTex,800,600);
        Image background=new Image(backgroundTexReg);

        stage.addActor(background);

        this.btnPlay = new TextButton("Play", this.skin);
        this.btnPlay.setPosition(150,300);
        this.btnPlay.setSize(100,70);
        this.btnResume = new TextButton("Resume", skin);
        this.btnResume.setPosition(300,300);
        this.btnResume.setSize(150,70);

        this.btnAbout = new TextButton("About", skin);
        this.btnAbout.setPosition(500,300);
        this.btnAbout.setSize(120,70);
        stage.addActor(this.btnAbout);
        stage.addActor(this.btnPlay);
        stage.addActor(this.btnResume);




    }

    @Override
    public void render (float delta) {
        Gdx.gl.glClearColor(0,0,0,0);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        stage.draw();
        this.btnPlay.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y) {
                tanksStars.setScreen(new GameScreen());
            }
        });
        this.btnResume.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y) {
                tanksStars.setScreen(tanksStars.gameScreen);

            }
        });


    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }

}
