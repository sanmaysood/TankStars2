package com.tankstars.game;

public class BodyUserData {
    public String type;
    public int health;
    public int damage;
   public float speed;

}
