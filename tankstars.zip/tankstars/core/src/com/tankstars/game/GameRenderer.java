package com.tankstars.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;

public class GameRenderer  {
    GameWorld world;
    OrthographicCamera camera;
    Box2DDebugRenderer renderer;
    public GameRenderer(GameWorld world){
        this.world=world;
        this.renderer=new Box2DDebugRenderer();
        this.camera=(OrthographicCamera)world.stage.getCamera();
        this.camera.position.set(400,300,0);

    }
    public void render(){
        this.camera.position.set(400,300,0);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        camera.update();
        this.renderer.render(world.box2dworld, camera.combined);
        this.world.stage.draw();
    }
}
