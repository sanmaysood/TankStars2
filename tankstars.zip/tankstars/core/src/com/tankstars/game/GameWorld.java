package com.tankstars.game;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.FitViewport;

public class GameWorld {
    public final Stage stage;
    public final World box2dworld;

    private light_tank_actor light_tank_actor;
    private infantry_tank_actor infantry_tank_actor;
    private cavalry_tank_actor cavalry_tank_actor;
    public static final Vector2 gravity = new Vector2(0, -9.8f);

    public GameWorld() {

        this.box2dworld = new World(gravity, true);
        FitViewport viewport = new FitViewport(800, 480);
        this.stage= new Stage(viewport);

        createWorld();
    }
    private void createWorld(){
        this.light_tank_actor = new light_tank_actor(this);
        this.infantry_tank_actor = new infantry_tank_actor();
        this.cavalry_tank_actor = new cavalry_tank_actor();
        this.stage.addActor(light_tank_actor);
        this.stage.addActor(infantry_tank_actor);
        this.stage.addActor(cavalry_tank_actor);
    }
    public void update(float delta) {
        //game logic here

        this.box2dworld.step(delta, 3, 3);
        this.stage.act(delta);
    }

}
