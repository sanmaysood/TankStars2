package com.tankstars.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;

public class ChooseTanksScreen implements Screen {
    private TanksStars tanksStars;
    private Stage stage;
    private Skin skin;
    private TextButton btnLight;
    private TextButton btnInfantry;
    private TextButton btnCavalry;



    public ChooseTanksScreen(TanksStars tanksStars){
        this.tanksStars=tanksStars;
        this.stage=new Stage();



    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
        stage.clear();
        this.skin= new Skin(Gdx.files.internal("skin/craftacular-ui.json"));

        Texture backgroundTex=new Texture(Gdx.files.internal("ChooseTanksScreen.png"));
        TextureRegion backgroundTexReg= new TextureRegion(backgroundTex,800,600);
        Image background=new Image(backgroundTexReg);

        stage.addActor(background);

        this.btnLight = new TextButton("Light", this.skin);
        this.btnLight.setPosition(100,250);
        this.btnLight.setSize(100,70);
        this.btnInfantry = new TextButton("Infantry", skin);
        this.btnInfantry.setPosition(270,250);
        this.btnInfantry.setSize(170,70);

        this.btnCavalry = new TextButton("Cavalry", skin);
        this.btnCavalry.setPosition(520,250);
        this.btnCavalry.setSize(160,70);
        stage.addActor(this.btnCavalry);
        stage.addActor(this.btnLight);
        stage.addActor(this.btnInfantry);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0,0,0,0);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        stage.draw();

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
