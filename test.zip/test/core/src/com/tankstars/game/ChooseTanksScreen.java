package com.tankstars.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

public class ChooseTanksScreen implements Screen {
    private TanksStars tanksStars;
    private Stage stage;
    private Skin skin;
    private TextButton btnLight;
    private TextButton btnInfantry;
    private TextButton btnCavalry;
    private boolean isLight;
    private boolean isInfantry;
    private boolean isCavalry;
    private Texture backgroundTex;
    private TextureRegion backgroundTexReg;
    private Image background;
    private ChooseTanksScreen chooseTanksScreen;
    private Music music;



    public ChooseTanksScreen(TanksStars tanksStars){
        this.tanksStars=tanksStars;
        this.stage=new Stage();
        this.chooseTanksScreen=this;

    }

    @Override
    public void show() {

        Gdx.input.setInputProcessor(stage);
        stage.clear();
        this.skin= new Skin(Gdx.files.internal("skin/craftacular-ui.json"));

        backgroundTex=new Texture(Gdx.files.internal("ChooseTanksScreen.png"));
        backgroundTexReg= new TextureRegion(backgroundTex,800,600);
        background=new Image(backgroundTexReg);

        stage.addActor(background);
        music = Gdx.audio.newMusic(Gdx.files.internal("tankstars.mp3"));

        music.setVolume(0.5f);
        music.setLooping(true);
        music.play();


        this.btnLight = new TextButton("Light", this.skin);
        this.btnLight.setPosition(100,250);
        this.btnLight.setSize(100,70);

        this.btnInfantry = new TextButton("Infantry", skin);
        this.btnInfantry.setPosition(270,250);
        this.btnInfantry.setSize(170,70);

        this.btnCavalry = new TextButton("Cavalry", skin);
        this.btnCavalry.setPosition(520,250);
        this.btnCavalry.setSize(160,70);

        stage.addActor(this.btnCavalry);
        stage.addActor(this.btnLight);
        stage.addActor(this.btnInfantry);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0,0,0,0);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        stage.draw();

        this.btnCavalry.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y) {
                isCavalry=true;
            }
        });

        this.btnInfantry.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y) {
                isInfantry=true;
            }
        });

        this.btnLight.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y) {
                isLight=true;
            }
        });

        if (isLight && isCavalry) {
            music.stop();
            chooseTanksScreen.dispose();
            tanksStars.setScreen(new GameScreen(tanksStars, true, false, true));
        }
        else if (isLight && isInfantry) {
            music.stop();
            chooseTanksScreen.dispose();
            tanksStars.setScreen(new GameScreen(tanksStars, true, true, false));
        }
        else if (isCavalry && isInfantry) {
            music.stop();
            chooseTanksScreen.dispose();
            tanksStars.setScreen(new GameScreen(tanksStars, false, true, true));
        }


    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        skin.dispose();
        stage.dispose();
        backgroundTex.dispose();
        backgroundTexReg.getTexture().dispose();
        background.remove();
        music.dispose();


    }
}
