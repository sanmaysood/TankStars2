package com.tankstars.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.scenes.scene2d.Actor;

public class cavalry_tank_actor extends Actor {
    Sprite sprite;
    float x,y,speed;

    public cavalry_tank_actor(){
        this.sprite=new Sprite(new Texture("cavalry_tank.png"));
//        this.sprite.flip(true,false);

    }
    public void flipper(){
        this.sprite.flip(true,false);
    }
    @Override
    public void draw(Batch batch,float parentAlpha){

        sprite.draw(batch);
    }
    @Override
    public void act(float delta){
        super.act(delta);
    }

}