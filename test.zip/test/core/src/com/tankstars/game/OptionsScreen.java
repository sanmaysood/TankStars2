package com.tankstars.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;

public class OptionsScreen implements Screen {
    private final TanksStars tanksStars;
    private Stage stage;
    private Skin skin;
    private Texture backgroundTex;
    private TextureRegion backgroundTexReg;
    private Image background;
    private TextButton btnResume;
    private TextButton btnRestart;
    private TextButton btnMainMenu;
    private TextButton btnSave;
    private ImageButton btnBack;
    private GameScreen gameScreen;
    private OptionsScreen optionsScreen;
    private Music music;

    public OptionsScreen(TanksStars tanksStars){
        this.tanksStars=tanksStars;
        this.stage=new Stage();

    }
    public OptionsScreen(TanksStars tanksStars,GameScreen gameScreen){
        this.tanksStars=tanksStars;
        this.stage=new Stage();
        this.gameScreen=gameScreen;
        this.optionsScreen=this;
    }

    @Override
    public void show() {

        Gdx.input.setInputProcessor(stage);
        stage.clear();
        this.skin= new Skin(Gdx.files.internal("skin/craftacular-ui.json"));

        backgroundTex = new Texture(Gdx.files.internal("OptionsMenu.png"));
        backgroundTexReg = new TextureRegion(backgroundTex,800,600);
        background = new Image(backgroundTexReg);

        stage.addActor(background);

        music = Gdx.audio.newMusic(Gdx.files.internal("tankstars.mp3"));

        music.setVolume(0.5f);
        music.setLooping(true);
        music.play();

        this.btnResume = new TextButton("RESUME", this.skin);
        this.btnResume.setPosition(300,400);
        this.btnResume.setSize(200,70);
        this.btnRestart = new TextButton("RESTART", skin);
        this.btnRestart.setPosition(300,300);
        this.btnRestart.setSize(200,70);

        this.btnMainMenu = new TextButton("MAIN MENU", skin);
        this.btnMainMenu.setPosition(300,100);
        this.btnMainMenu.setSize(200,70);

        this.btnSave=new TextButton("SAVE",this.skin);
        this.btnSave.setPosition(300,200);
        this.btnSave.setSize(200,70);

        this.btnBack=new ImageButton(skin);
        this.btnBack.setSize(60,60);
        this.btnBack.getStyle().imageUp=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("BackButton.png"))));
        this.btnBack.getStyle().imageDown=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("BackButton.png"))));
        this.btnBack.setPosition(800-80,600-80);

        stage.addActor(this.btnRestart);
        stage.addActor(this.btnMainMenu);
        stage.addActor(this.btnResume);
        stage.addActor(this.btnSave);
        stage.addActor(this.btnBack);

    }


    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0,0,0,0);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        stage.draw();

        this.btnMainMenu.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y) {
                music.stop();
                optionsScreen.dispose();
                tanksStars.setScreen(new PreloginScreen(tanksStars));
            }
        });

        this.btnRestart.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y) {
                music.stop();
                optionsScreen.dispose();
                tanksStars.setScreen(new ChooseTanksScreen(tanksStars));
            }
        });

//        this.btnResume.addListener(new ClickListener(){
//            @Override
//            public void clicked(InputEvent event, float x, float y) {
//                gameScreen.resume();
//            }
//        });
//
        this.btnBack.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y) {
                music.stop();
                tanksStars.setScreen(gameScreen);
            }
        });

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

        stage.dispose();
        skin.dispose();
        backgroundTex.dispose();
        backgroundTexReg.getTexture().dispose();
        background.remove();
        music.dispose();

    }
}
