package com.tankstars.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;

import java.util.ArrayList;
import java.util.Iterator;

public class GameScreen implements Screen {
    private Stage stage;
    private Skin skin;
    private light_tank_actor light_tank_actor;
    private infantry_tank_actor infantry_tank_actor;
    private cavalry_tank_actor cavalry_tank_actor;
    private Label gameLabel,player_1_Label,player_2_Label;
    private shootButton shootButton_P_1;
    private shootButton shootButton_P_2;
    private powerButton powerButton_P_1,powerButton_P_2;
    private ImageButton btnOptions;
    private ImageButton btnShoot;
    private TanksStars tanksStars;
    private boolean isLightTank;
    private boolean isInfantryTank;
    private boolean isCavalryTank;
    private Music music;
    private Texture backgroundTex;
    private TextureRegion backgroundTexReg;
    private Image background;
    private GameScreen gameScreen;
    ArrayList<Object> list = new ArrayList<Object>();

    public GameScreen(TanksStars tanksStars, boolean isLightTank, boolean isInfantryTank, boolean isCavalryTank){

        this.stage=new Stage();
        this.tanksStars=tanksStars;
        this.isLightTank=isLightTank;
        this.isInfantryTank=isInfantryTank;
        this.isCavalryTank=isCavalryTank;
        tanksStars.currentGameScreen = this;
        tanksStars.savedGames.add(this);
        this.gameScreen=this;
    }


    @Override
    public void show() {

        music = Gdx.audio.newMusic(Gdx.files.internal("gameTheme.mp3"));

        music.setVolume(0.5f);
        music.setLooping(true);
        music.play();

        stage.clear();
        this.skin= new Skin(Gdx.files.internal("skin/craftacular-ui.json"));

        backgroundTex=new Texture(Gdx.files.internal("GameBackground.png"));
        backgroundTexReg= new TextureRegion(backgroundTex,800,600);
        background=new Image(backgroundTexReg);

        gameLabel=new Label(" GameID:404",skin,"bold");
        gameLabel.setSize(250,50);
        gameLabel.setPosition(290,480);

        player_1_Label=new Label("P1",skin,"xp");
        player_1_Label.setSize(35,35);
        player_1_Label.setPosition(10,380);

        player_2_Label=new Label("P2",skin,"xp");
        player_2_Label.setSize(35,35);
        player_2_Label.setPosition(750,380);


        this.light_tank_actor=new light_tank_actor();
        this.cavalry_tank_actor=new cavalry_tank_actor();
        this.infantry_tank_actor=new infantry_tank_actor();

        if(isLightTank){
            this.light_tank_actor.x = 800-10-light_tank_actor.sprite.getWidth();
            this.light_tank_actor.y = 120;
            this.light_tank_actor.speed = 110;
            this.light_tank_actor.sprite.setPosition(this.light_tank_actor.x,this.light_tank_actor.y);
        }

        if(isInfantryTank){
            this.infantry_tank_actor.flipper();
            this.infantry_tank_actor.x = 10;
            this.infantry_tank_actor.y = 150;
            this.infantry_tank_actor.speed = 100;
            this.infantry_tank_actor.sprite.setPosition(this.infantry_tank_actor.x,this.infantry_tank_actor.y);
        }

        if(isCavalryTank && isLightTank){
            this.cavalry_tank_actor.flipper();
            this.cavalry_tank_actor.x = 10;
            this.cavalry_tank_actor.y = 150;
            this.cavalry_tank_actor.speed = 90;
            this.cavalry_tank_actor.sprite.setPosition(this.cavalry_tank_actor.x,this.cavalry_tank_actor.y);
        }

        if(isCavalryTank && isInfantryTank){
            this.cavalry_tank_actor.x = 800-10-cavalry_tank_actor.sprite.getWidth();
            this.cavalry_tank_actor.y = 150;
            this.cavalry_tank_actor.speed = 90;
            this.cavalry_tank_actor.sprite.setPosition(this.cavalry_tank_actor.x,this.cavalry_tank_actor.y);
        }




        //this.cavalry_tank_actor.sprite.setPosition(400,150);

        this.btnOptions=new ImageButton(skin);
        this.btnOptions.setSize(60,60);
        this.btnOptions.getStyle().imageUp=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("OptionsButton.png"))));
        this.btnOptions.getStyle().imageDown=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("OptionsButton.png"))));
        this.btnOptions.setPosition(800-80,600-80);

        this.btnOptions=new ImageButton(skin);
        this.btnOptions.setSize(60,60);
        this.btnOptions.getStyle().imageUp=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("OptionsButton.png"))));
        this.btnOptions.getStyle().imageDown=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("OptionsButton.png"))));
        this.btnOptions.setPosition(800-80,600-80);

        this.btnOptions=new ImageButton(skin);
        this.btnOptions.setSize(60,60);
        this.btnOptions.getStyle().imageUp=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("OptionsButton.png"))));
        this.btnOptions.getStyle().imageDown=new TextureRegionDrawable(new TextureRegion(new Texture(Gdx.files.internal("OptionsButton.png"))));
        this.btnOptions.setPosition(800-80,600-80);

        this.shootButton_P_1=new shootButton();
        this.shootButton_P_2=new shootButton();
        this.shootButton_P_1.sprite.setPosition(10,70);
        this.shootButton_P_2.sprite.setPosition(750,70);

        this.powerButton_P_1=new powerButton();
        this.powerButton_P_2=new powerButton();
        this.powerButton_P_1.sprite.setPosition(10,10);
        this.powerButton_P_2.sprite.setPosition(750,10);

//        list.add(background);
//        list.add(gameLabel);
//        list.add(player_1_Label);
//        list.add(player_2_Label);
//        list.add(shootButton_P_1);
//        list.add(shootButton_P_2);
//        list.add(powerButton_P_1);
//        list.add(powerButton_P_2);
//
//        Iterator<Object> iterator = list.iterator();

        stage.addActor(background);
        stage.addActor(gameLabel);
        stage.addActor(player_1_Label);
        stage.addActor(player_2_Label);
        stage.addActor(this.btnOptions);
        stage.addActor(shootButton_P_1);
        stage.addActor(shootButton_P_2);
        stage.addActor(powerButton_P_1);
        stage.addActor(powerButton_P_2);
        Gdx.input.setInputProcessor(stage);

        if(isLightTank){
            stage.addActor(this.light_tank_actor);
        }
        if(isInfantryTank){
            stage.addActor(this.infantry_tank_actor);
        }
        if(isCavalryTank){
            stage.addActor(this.cavalry_tank_actor);
        }


    }

    @Override
    public void render(float delta) {

        Gdx.gl.glClearColor(0,0,0,0);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        stage.act();
        stage.draw();

        final GameScreen gs = this;

        this.btnOptions.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y) {
                music.stop();
                gameScreen.dispose();
                tanksStars.setScreen(new OptionsScreen(tanksStars, gs));
            }
        });

        float deltaTime = Gdx.graphics.getDeltaTime();

        if(isLightTank){
            if(Gdx.input.isKeyPressed(Input.Keys.LEFT)){
                this.light_tank_actor.x -= this.light_tank_actor.speed * deltaTime;
                this.light_tank_actor.sprite.setPosition(this.light_tank_actor.x,this.light_tank_actor.y);
            }

            if(Gdx.input.isKeyPressed(Input.Keys.RIGHT)){
                this.light_tank_actor.x += this.light_tank_actor.speed * deltaTime;
                this.light_tank_actor.sprite.setPosition(this.light_tank_actor.x,this.light_tank_actor.y);
            }
        }

        if(isCavalryTank){
            if(Gdx.input.isKeyPressed(Input.Keys.A)){
                this.cavalry_tank_actor.x -= this.cavalry_tank_actor.speed * deltaTime;
                this.cavalry_tank_actor.sprite.setPosition(this.cavalry_tank_actor.x,this.cavalry_tank_actor.y);
            }

            if(Gdx.input.isKeyPressed(Input.Keys.D)){
                this.cavalry_tank_actor.x += this.cavalry_tank_actor.speed * deltaTime;
                this.cavalry_tank_actor.sprite.setPosition(this.cavalry_tank_actor.x,this.cavalry_tank_actor.y);
            }
        }

        if(isInfantryTank && isLightTank){
            if(Gdx.input.isKeyPressed(Input.Keys.A)){
                this.infantry_tank_actor.x -= this.infantry_tank_actor.speed * deltaTime;
                this.infantry_tank_actor.sprite.setPosition(this.infantry_tank_actor.x,this.infantry_tank_actor.y);
            }

            if(Gdx.input.isKeyPressed(Input.Keys.D)){
                this.infantry_tank_actor.x += this.infantry_tank_actor.speed * deltaTime;
                this.infantry_tank_actor.sprite.setPosition(this.infantry_tank_actor.x,this.infantry_tank_actor.y);
            }
        }

        if(isInfantryTank && isCavalryTank){
            if(Gdx.input.isKeyPressed(Input.Keys.LEFT)){
                this.infantry_tank_actor.x -= this.infantry_tank_actor.speed * deltaTime;
                this.infantry_tank_actor.sprite.setPosition(this.infantry_tank_actor.x,this.infantry_tank_actor.y);
            }

            if(Gdx.input.isKeyPressed(Input.Keys.RIGHT)){
                this.infantry_tank_actor.x += this.infantry_tank_actor.speed * deltaTime;
                this.infantry_tank_actor.sprite.setPosition(this.infantry_tank_actor.x,this.infantry_tank_actor.y);
            }
        }




    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        skin.dispose();
        stage.dispose();
        backgroundTex.dispose();
        music.dispose();
        backgroundTexReg.getTexture().dispose();
        background.remove();
        shootButton_P_1.remove();
        shootButton_P_2.remove();
        powerButton_P_1.remove();
        powerButton_P_2.remove();
        gameLabel.remove();
        player_1_Label.remove();
        player_2_Label.remove();
        btnOptions.remove();
        light_tank_actor.remove();
        infantry_tank_actor.remove();
        cavalry_tank_actor.remove();

    }
}

