package com.tankstars.game;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.scenes.scene2d.Actor;

public class infantry_tank_actor extends Actor {
    Sprite sprite;
    float x,y,speed;

    public infantry_tank_actor(){
        this.sprite=new Sprite(new Texture("infantry_tank.png"));
    }
    public void flipper(){
        this.sprite.flip(true,false);
    }
    @Override
    public void draw(Batch batch,float parentAlpha){

        sprite.draw(batch);
    }
    @Override
    public void act(float delta){
        super.act(delta);
    }

}

