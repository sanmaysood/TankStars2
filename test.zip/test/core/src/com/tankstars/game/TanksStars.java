package com.tankstars.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;

import java.util.ArrayList;
import java.util.LinkedList;

//by Sanmay(2021095) & Aniket(2021231)

public class TanksStars extends Game {
	private static TanksStars instance = null;
	public PreloginScreen preloginScreen;
	public OptionsScreen optionsScreen;
	public GameScreen currentGameScreen;
	public ChooseTanksScreen chooseTanksScreen;
	public SavedGamesScreen savedGamesScreen;
	public LinkedList<GameScreen> savedGames = new LinkedList<>();


	public static synchronized TanksStars getInstance() {
		if (instance == null) {
			instance = new TanksStars();
		}
		return instance;
	}

	private TanksStars() {
	}

	
	@Override
	public void create () {
		preloginScreen=new PreloginScreen(this);
		optionsScreen=new OptionsScreen(this);
		chooseTanksScreen=new ChooseTanksScreen(this);
		savedGamesScreen=new SavedGamesScreen(this);


		this.setScreen(preloginScreen);

	}

	@Override
	public void render () {
		super.render();

	}
	
	@Override
	public void dispose () {

	}
}
